# Install Navi for Claude Code

This folder contains the actual Navi files in a visible staging layout. It contains no executable installer or runtime.

## Instructions for the AI agent

This package targets Claude Code. If that does not match the current AI coding agent, stop and tell the user to download the correct package.

Install Navi only into the currently open project. The package may be in Downloads or a temporary extraction directory; never treat that source directory as the project.
The user's request to install Navi is explicit approval to create missing directories and copy new Navi files. Do not ask for another confirmation when every destination file is missing or byte-for-byte identical to the staged file.

1. Resolve paths relative to this `INSTALL.md` and confirm that `skills` contains exactly these 12 folders: navi-branches, navi-check, navi-compare, navi-github-connect, navi-history, navi-merge, navi-restore, navi-save, navi-settings, navi-setup, navi-status, navi-sync.
2. Inspect the destination `.claude/skills` and `.navi/NAVI.md` before changing anything.
3. Classify every destination file as new, identical, or conflicting.
4. If the package inventory is invalid or any destination file is conflicting, stop and explain the problem. Ask the user what to do only for conflicting files. Never overwrite unrelated files or replace an entire existing folder.
5. If every destination file is new or identical, proceed immediately without presenting a plan or requesting approval. Create only missing directories, copy new `skills/navi-*/SKILL.md` files into `.claude/skills/navi-*/SKILL.md`, and copy a new `shared/NAVI.md` to `.navi/NAVI.md`. Do not rewrite identical files.
6. Verify that all 12 skills and `.navi/NAVI.md` exist at their destinations and match the staged files.
7. Report the result. Remove only a temporary extraction directory you created. Never delete the downloaded ZIP or a user-created extracted folder.
8. Tell the user to reload Claude Code and say: “Set up Navi.”

Do not modify `AGENTS.md`, `CLAUDE.md`, existing non-Navi skills, credentials, Git history, branches, or remotes during installation.
