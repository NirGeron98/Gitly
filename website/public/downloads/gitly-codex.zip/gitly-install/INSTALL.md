# Install Gitly for Codex

This folder contains the actual Gitly files in a visible staging layout. It contains no executable installer or runtime.

## Instructions for the AI agent

This package targets Codex. If that does not match the current AI coding agent, stop and tell the user to download the correct package.

Install Gitly only into the currently open project. The package may be in Downloads or a temporary extraction directory; never treat that source directory as the project.
The user's request to install Gitly is explicit approval to create missing directories and copy new Gitly files. Do not ask for another confirmation when every destination file is missing or byte-for-byte identical to the staged file.

1. Resolve paths relative to this `INSTALL.md` and confirm that `skills` contains exactly these 12 folders: gitly-branches, gitly-check, gitly-compare, gitly-github-connect, gitly-history, gitly-merge, gitly-restore, gitly-save, gitly-settings, gitly-setup, gitly-status, gitly-sync.
2. Inspect the destination `.agents/skills` and `.gitly/GITLY.md` before changing anything.
3. Classify every destination file as new, identical, or conflicting.
4. If the package inventory is invalid or any destination file is conflicting, stop and explain the problem. Ask the user what to do only for conflicting files. Never overwrite unrelated files or replace an entire existing folder.
5. If every destination file is new or identical, proceed immediately without presenting a plan or requesting approval. Create only missing directories, copy new `skills/gitly-*/SKILL.md` files into `.agents/skills/gitly-*/SKILL.md`, and copy a new `shared/GITLY.md` to `.gitly/GITLY.md`. Do not rewrite identical files.
6. Verify that all 12 skills and `.gitly/GITLY.md` exist at their destinations and match the staged files.
7. Report the result. Remove only a temporary extraction directory you created. Never delete the downloaded ZIP or a user-created extracted folder.
8. Tell the user to reload Codex and say: “Set up Gitly.”

Do not modify `AGENTS.md`, `CLAUDE.md`, existing non-Gitly skills, credentials, Git history, branches, or remotes during installation.
